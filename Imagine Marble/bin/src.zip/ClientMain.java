import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;

public class ClientMain extends JFrame {

	private JPanel contentPane;
	private JTextField txtUserName;
	private JTextField txtIpAdress;
	private JTextField txtPortNumber;

	private Socket socket; // �������
	private ObjectInputStream ois;
	private ObjectOutputStream oos;

	private ClientGameRoom GameRoom = new ClientGameRoom();
	private ClientInGame InGame = new ClientInGame();

	private String myName;
	private int myRoomNumber;

	/**
	 * Launch the application.
	 */

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClientMain frame = new ClientMain();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */

	public ClientMain() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1024, 768);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel GameName = new JLabel("��� ����");
		GameName.setForeground(Color.BLUE);
		GameName.setFont(new Font("�������ü", Font.BOLD, 60));
		GameName.setHorizontalAlignment(SwingConstants.CENTER);
		GameName.setBounds(334, 41, 340, 88);
		contentPane.add(GameName);

		JLabel MainImage = new JLabel();
		MainImage.setHorizontalAlignment(SwingConstants.CENTER);
		MainImage.setIcon(new ImageIcon("Images/mainImage.png"));
		MainImage.setBounds(342, 150, 324, 260);
		contentPane.add(MainImage);

		JLabel NickName = new JLabel("�г���");
		NickName.setFont(new Font("���� ������ 240", Font.PLAIN, 20));
		NickName.setHorizontalAlignment(SwingConstants.CENTER);
		NickName.setBounds(357, 457, 109, 36);
		contentPane.add(NickName);

		txtUserName = new JTextField();
		txtUserName.setHorizontalAlignment(SwingConstants.CENTER);
		txtUserName.setBounds(463, 457, 166, 36);
		contentPane.add(txtUserName);
		txtUserName.setColumns(10);

		JLabel IpAdress = new JLabel("Ip Adress");
		IpAdress.setFont(new Font("����", Font.BOLD, 15));
		IpAdress.setHorizontalAlignment(SwingConstants.CENTER);
		IpAdress.setBounds(367, 502, 82, 30);
		contentPane.add(IpAdress);

		JLabel PortNumber = new JLabel("Port Number");
		PortNumber.setHorizontalAlignment(SwingConstants.CENTER);
		PortNumber.setFont(new Font("����", Font.BOLD, 13));
		PortNumber.setBounds(367, 535, 82, 30);
		contentPane.add(PortNumber);

		txtIpAdress = new JTextField();
		txtIpAdress.setHorizontalAlignment(SwingConstants.CENTER);
		txtIpAdress.setText("127.0.0.1");
		txtIpAdress.setBounds(461, 507, 168, 21);
		contentPane.add(txtIpAdress);
		txtIpAdress.setColumns(10);

		txtPortNumber = new JTextField();
		txtPortNumber.setHorizontalAlignment(SwingConstants.CENTER);
		txtPortNumber.setText("30000");
		txtPortNumber.setColumns(10);
		txtPortNumber.setBounds(461, 540, 168, 21);
		contentPane.add(txtPortNumber);

		JButton btnStart = new JButton("����");
		btnStart.setBounds(434, 640, 140, 46);
		contentPane.add(btnStart);
		Myaction action = new Myaction();
		btnStart.addActionListener(action);
		txtUserName.addActionListener(action);
		txtIpAdress.addActionListener(action);
		txtPortNumber.addActionListener(action);


		for (int i = 0; i < 4; i++) {
			PressJoin pj = new PressJoin();
			GameRoom.JoinBtns[i].addActionListener(pj);
		}
		
		PressOut po = new PressOut();
		InGame.OutBtn.addActionListener(po);
	}

	public void AppendText(String msg) {
		msg = msg.trim(); // �յ� blank�� \n�� �����Ѵ�.
	}

	public void SendChatMsg(ChatMsg obj) {
		try {
			oos.writeObject(obj.code);
			oos.writeObject(obj.UserName);
			oos.writeObject(obj.data);
			if (obj.code.equals("300")) { // �̹��� ÷�� �ִ� ���
				oos.writeObject(obj.imgbytes);
			}
			oos.flush();
		} catch (IOException e) {
			AppendText("SendChatMsg Error");
			e.printStackTrace();
			try {
				oos.close();
				socket.close();
				ois.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

	public ChatMsg ReadChatMsg() {
		Object obj = null;
		String msg = null;
		ChatMsg cm = new ChatMsg("", "", "");
		// Android�� ȣȯ���� ���� ������ Field�� ���ε��� �д´�.

		try {
			obj = ois.readObject();
			cm.code = (String) obj;
			obj = ois.readObject();
			cm.UserName = (String) obj;
			obj = ois.readObject();
			cm.data = (String) obj;
			if (cm.code.equals("300")) {
				obj = ois.readObject();
				cm.imgbytes = (byte[]) obj;
			}
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			AppendText("ReadChatMsg Error");
			e.printStackTrace();
			try {
				oos.close();
				socket.close();
				ois.close();
				socket = null;
				return null;
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				try {
					oos.close();
					socket.close();
					ois.close();
				} catch (IOException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}

				socket = null;
				return null;
			}
		}

		return cm;
	}

	class ListenNetwork extends Thread {
		public void run() {
			while (true) {
				ChatMsg cm = ReadChatMsg();
				if (cm == null)
					break;
				if (socket == null)
					break;
				String msg;
				msg = String.format("[%s] %s", cm.UserName, cm.data);
				switch (cm.code) {
				case "200": // chat message
					AppendText(msg);
					break;
				case "300": // Image ÷��
					AppendText("[" + cm.UserName + "]" + " " + cm.data);
					break;

				case "602":
					String[] RoomData = cm.data.split(" ");
					GameRoom.PlayerCnt[Integer.parseInt(RoomData[0]) - 1].setText(RoomData[1] + "   /   4");
					System.out.println("602");
					break;
				case "444":

				}

			}
		}
	}

	class Myaction implements ActionListener // �� ó�� ���� ��ư
	{
		@Override
		public void actionPerformed(ActionEvent e) {
			myName = txtUserName.getText().trim();
			String ip_addr = txtIpAdress.getText().trim();
			String port_no = txtPortNumber.getText().trim();
			try {
				socket = new Socket(ip_addr, Integer.parseInt(port_no));
				oos = new ObjectOutputStream(socket.getOutputStream());
				oos.flush();
				ois = new ObjectInputStream(socket.getInputStream());

				ChatMsg obcm = new ChatMsg(myName, "100", "Hello");
				SendChatMsg(obcm);

				ListenNetwork net = new ListenNetwork();
				net.start();
			} catch (NumberFormatException | IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				AppendText("connect error");
			}

			setVisible(false);
			GameRoom.setVisible(true);

			GameRoom.NameLabel.setText(myName + " �� �ȳ��ϼ���!");
		}
	}

	class PressJoin implements ActionListener { // �� ���� ��ư
		public void actionPerformed(ActionEvent e) {
			for (int i = 0; i < 4; i++) {
				if (e.getSource() == GameRoom.JoinBtns[i]) {
					myRoomNumber = i + 1;
					ChatMsg obcm = new ChatMsg(myName, "600", myRoomNumber + "");
					SendChatMsg(obcm);
					break;
				}
			}
			GameRoom.setVisible(false);
			InGame.setVisible(true);
		}
	}

	class PressOut implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			ChatMsg obcm = new ChatMsg(myName, "601", myRoomNumber + "");
			SendChatMsg(obcm);
			myRoomNumber = 0;
			InGame.setVisible(false);
			GameRoom.setVisible(true);
		}
	}
}
