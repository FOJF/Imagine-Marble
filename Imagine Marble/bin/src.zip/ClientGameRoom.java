import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JLabel;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Random;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Label;

public class ClientGameRoom extends JFrame {

	JLabel NameLabel = new JLabel();

	JPanel[] RoomList = new JPanel[4]; // �� ��� JPanel
	JLabel[] RoomNames = new JLabel[4]; // �� �̸�
	JLabel[] PlayerMax = new JLabel[4]; // �ִ� �ο���
	JLabel[] PlayerCnt = new JLabel[4]; // �� ���� �ο���
	JButton[] JoinBtns = new JButton[4]; // ���� ��ư

	/**
	 * Create the frame.
	 */
	public ClientGameRoom() {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1024, 768);
		getContentPane().setLayout(null);

		NameLabel.setFont(new Font("���� ������ 240", Font.PLAIN, 15));
		NameLabel.setHorizontalAlignment(SwingConstants.CENTER);
		NameLabel.setBounds(0, 0, 200, 32);
		getContentPane().add(NameLabel);

		JLabel RoomListLabel = new JLabel("�� ���");
		RoomListLabel.setFont(new Font("���� �Ҹ� B", Font.PLAIN, 25));
		RoomListLabel.setHorizontalAlignment(SwingConstants.CENTER);
		RoomListLabel.setBounds(404, 65, 200, 50);
		getContentPane().add(RoomListLabel);

		for (int i = 0; i < 4; i++) {
			RoomList[i] = new JPanel();
			if (i < 2)
				RoomList[i].setBounds(12 + i * 532, 135, 464, 244);
			else
				RoomList[i].setBounds(12 + (i - 2) * 532, 409, 464, 244);

			RoomList[i].setForeground(Color.DARK_GRAY);
			RoomList[i].setLayout(null);

			RoomNames[i] = new JLabel();
			RoomNames[i].setHorizontalAlignment(SwingConstants.CENTER);
			RoomNames[i].setFont(new Font("���� ����", Font.BOLD, 15));
			RoomNames[i].setBounds(200, 10, 64, 39);
			RoomNames[i].setText((i + 1) + " ����");
			RoomList[i].add(RoomNames[i]);

			PlayerMax[i] = new JLabel();
			PlayerMax[i].setBounds(58, 86, 57, 15);
			PlayerMax[i].setText("�ο���");
			RoomList[i].add(PlayerMax[i]);

			PlayerCnt[i] = new JLabel();
			PlayerCnt[i].setBounds(195, 86, 69, 23);
			PlayerCnt[i].setText("0   /   4");
			RoomList[i].add(PlayerCnt[i]);

			JoinBtns[i] = new JButton();
			JoinBtns[i].setBounds(176, 196, 97, 23);
			JoinBtns[i].setText("����");
			RoomList[i].add(JoinBtns[i]);

			getContentPane().add(RoomList[i]);
		}
	}

}
