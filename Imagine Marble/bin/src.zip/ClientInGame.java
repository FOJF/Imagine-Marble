import java.awt.EventQueue;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Font;

public class ClientInGame extends JFrame {

	private JLabel Dice1 = new JLabel("");
	private JLabel Dice2 = new JLabel("");

	JLabel[] LandName = new JLabel[22];
	
	JLabel[] UserNames = new JLabel[4];
	JLabel[] UserMoneys = new JLabel[4];
	
	JLabel[] Dices = new JLabel[2];
	
	JButton OutBtn = new JButton("������");

	public ClientInGame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1024, 768);
		getContentPane().setLayout(null);

		JButton btnRoll = new JButton("�ֻ��� ������");
		btnRoll.setFont(new Font("��ü�� ���� ����ü", Font.BOLD, 15));
		btnRoll.setBounds(434, 466, 140, 40);
		getContentPane().add(btnRoll);

		for (int i = 0; i < 4; i++) {
			UserNames[i] = new JLabel(i + " ����");
			UserMoneys[i] = new JLabel(i + " ����");

			if (i < 2) {
				UserNames[i].setBounds(12, 10 + 661 * i, 91, 15);
				UserNames[i].setHorizontalAlignment(SwingConstants.LEFT);

				UserMoneys[i].setBounds(12, 35 + 669 * i, 91, 15);
				UserMoneys[i].setHorizontalAlignment(SwingConstants.LEFT);
			} else {
				UserNames[i].setBounds(905, 10 + 661 * i, 91, 15);
				UserNames[i].setHorizontalAlignment(SwingConstants.RIGHT);
				System.out.println(i);
				UserMoneys[i].setBounds(905, 35 + 669 * i, 91, 15);
				UserMoneys[i].setHorizontalAlignment(SwingConstants.RIGHT);
			}
			getContentPane().add(UserNames[i]);
			getContentPane().add(UserMoneys[i]);
		}

		// JLabel Dice1 = new JLabel("");
		Dice1.setIcon(new ImageIcon("Images/6.PNG"));
		Dice1.setBounds(545, 312, 50, 50);
		getContentPane().add(Dice1);

		// JLabel Dice2 = new JLabel("");
		Dice2.setIcon(new ImageIcon("Images/6.PNG"));
		Dice2.setBounds(400, 312, 50, 50);
		getContentPane().add(Dice2);

		OutBtn.setBounds(609, 642, 140, 44);
		getContentPane().add(OutBtn);
	}
}
